package pl.javastart.model;

public class Mark {

}
