//package pl.javastart.model;
//
//import java.io.Serializable;
//
//import javax.persistence.Column;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//@Table(name="pupil")
//public class Subject implements Serializable {
//    
//    @Id
//    @GeneratedValue(strategy=GenerationType.IDENTITY)
//    @Column(name="subject_id")
//    private Long id;
//    private Schollclass schollclass;
//    @One
//    private Teacher teacher;
//    private String subjectName;
//    
//}
