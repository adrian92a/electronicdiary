
Dziennik elektroniczny -- Aplikacja Adrian Skorupa
